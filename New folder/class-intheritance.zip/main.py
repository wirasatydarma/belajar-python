
class Student(Person):
    reg_number = ""

  def __init__(self,name,reg_number):
     super().__init__(name)
     self.reg_number = reg_number

  def getInfo(self):
   print("This person's name is",self.name)
  
   def diagnose(self, patient):
    print("This doctor is diagnosis", subject)

  def treat(self,patient):
    print("This doctor is treating", subject)
    
  
    
student1 = Student("Mary","0123456")
student1.getInfo()
student1.study("Math")


  
  
  