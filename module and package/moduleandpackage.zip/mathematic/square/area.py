def square_area(side):
    result = side * side
    text = f"Area of the square is {result}"
    print(text)