def square_perimeter(side):
    result = side * 4
    text = f"Perimeter of the square is {result}"
    print(text)
  