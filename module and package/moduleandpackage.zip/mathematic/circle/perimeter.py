def circle_perimeter(radius):
    pi = 22/7
    result = 2 * pi * radius
    text = f"Perimeter of the circle is {result}"
    print(text)