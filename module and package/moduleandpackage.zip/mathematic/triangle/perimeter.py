def triangle_perimeter(base, hight):
    result = base + hight + hight
    text = f"Perimeter of the triangle is {result}"
    print(text)