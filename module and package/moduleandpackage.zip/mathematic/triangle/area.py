def triangle_area(base,hight):
    result = base * hight / 2
    text = f"Area of the triangle is {result}"
    print(text)