def area_of_square(side):
    result = side * side
    text = f"The area of the square is {result}"
    print(text)

def area_of_triangle(base, height):
    result = (base * height) / 2
    text = f"The area of the triangle is {result}"
    print(text)