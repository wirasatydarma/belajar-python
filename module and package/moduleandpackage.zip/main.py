from mathematic.square.area import square_area
from mathematic.triangle.area import triangle_area
from mathematic.circle.area import circle_area

square_area(15)
triangle_area(15, 15)
circle_area(12)

from mathematic.square.perimeter import square_perimeter
from mathematic.triangle.perimeter import triangle_perimeter
from mathematic.circle.perimeter import circle_perimeter


square_perimeter(15)
triangle_perimeter(15, 15)
circle_perimeter(12)
